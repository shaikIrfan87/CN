import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) throws Exception {
        // Create a DatagramSocket to communicate with the server
        DatagramSocket socket = new DatagramSocket();
        InetAddress ip = InetAddress.getLocalHost();
        byte[] sendByte = new byte[1024];
        byte[] receiveByte = new byte[1024];

        System.out.println("Client is ready to send messages...");

        // Create a BufferedReader for console input
        BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            // Data Sending
            System.out.print("Client: ");
            String sendStr = consoleInput.readLine(); // Modern alternative to DataInputStream.readLine()
            sendByte = sendStr.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendByte, sendByte.length, ip, 9861);
            socket.send(sendPacket);

            // Exit if client sends "exit"
            if (sendStr.equalsIgnoreCase("exit")) {
                System.out.println("Exiting chat...");
                break;
            }

            // Data Receiving
            DatagramPacket receivePacket = new DatagramPacket(receiveByte, receiveByte.length);
            socket.receive(receivePacket);
            String receiveStr = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
            System.out.println("Server: " + receiveStr);

            // Exit if server sends "exit"
            if (receiveStr.equalsIgnoreCase("exit")) {
                System.out.println("Server has terminated the chat.");
                break;
            }
        }

        // Close the socket
        socket.close();
    }
}
