import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) throws Exception {
        // Create a DatagramSocket to listen on port 9861
        DatagramSocket socket = new DatagramSocket(9861);
        byte[] receiveByte = new byte[1024];
        byte[] sendByte = new byte[1024];

        System.out.println("Server is running and waiting for client messages...");

        // Create a BufferedReader for console input
        BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            // Data Receiving
            DatagramPacket receivePacket = new DatagramPacket(receiveByte, receiveByte.length);
            socket.receive(receivePacket);
            String receiveStr = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
            System.out.println("Client: " + receiveStr);

            // Exit if client sends "exit"
            if (receiveStr.equalsIgnoreCase("exit")) {
                System.out.println("Client has terminated the chat.");
                break;
            }

            // Data Sending
            System.out.print("Server: ");
            String sendStr = consoleInput.readLine(); // Modern alternative to DataInputStream.readLine()
            sendByte = sendStr.getBytes();

            InetAddress ip = receivePacket.getAddress();
            int port = receivePacket.getPort();

            DatagramPacket sendPacket = new DatagramPacket(sendByte, sendByte.length, ip, port);
            socket.send(sendPacket);

            // Exit if server sends "exit"
            if (sendStr.equalsIgnoreCase("exit")) {
                System.out.println("Server is shutting down...");
                break;
            }
        }

        // Close the socket
        socket.close();
    }
}
