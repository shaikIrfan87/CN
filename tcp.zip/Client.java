import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws Exception {
        // Connect to the server on localhost at port 7888
        Socket s = new Socket("127.0.0.1", 7888);

        // Check if the client is connected
        if (s.isConnected()) {
            System.out.println("Connected to the server.");
        }

        // Create input and output streams for communication
        BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in)); // For console input
        DataOutputStream dout = new DataOutputStream(s.getOutputStream()); // For sending data to server
        DataInputStream din = new DataInputStream(s.getInputStream()); // For receiving data from server

        // Initial message
        String str = "Start Chat..............................................................................................";
        dout.writeUTF(str);
        System.out.println(str);

        // Communication loop
        while (true) {
            // Take client message from console
            System.out.print("Client: ");
            str = consoleInput.readLine(); // Modern method for console input
            dout.writeUTF(str); // Send the message to the server

            // Exit if the client sends "exit"
            if (str.equalsIgnoreCase("exit")) {
                System.out.println("Exiting chat...");
                break;
            }

            // Receive and print server's response
            str = din.readUTF();
            System.out.println("Server: " + str);

            // Exit if the server sends "exit"
            if (str.equalsIgnoreCase("exit")) {
                System.out.println("Server has closed the connection.");
                break;
            }
        }

        // Close resources
        din.close();
        dout.close();
        s.close();
    }
}
