import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws Exception {
        // Create a ServerSocket to listen on port 7888
        ServerSocket ss = new ServerSocket(7888);
        System.out.println("Server is running and waiting for a client to connect...");

        // Accept the incoming client connection
        Socket s = ss.accept();
        System.out.println("Client connected!");

        // Create input and output streams for communication
        DataInputStream din = new DataInputStream(s.getInputStream());
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        Scanner scanner = new Scanner(System.in);

        String clientMessage, serverMessage;

        // Communication loop
        while (true) {
            // Read the message from the client
            clientMessage = din.readUTF();
            System.out.println("Client: " + clientMessage);

            // Exit if the client sends "exit"
            if (clientMessage.equalsIgnoreCase("exit")) {
                System.out.println("Client disconnected.");
                break;
            }

            // Take server response from console
            System.out.print("Server: ");
            serverMessage = scanner.nextLine();

            // Send the server's message to the client
            dout.writeUTF(serverMessage);

            // Exit if the server sends "exit"
            if (serverMessage.equalsIgnoreCase("exit")) {
                System.out.println("Server shutting down...");
                break;
            }
        }

        // Close resources
        din.close();
        dout.close();
        s.close();
        ss.close();
    }
}
